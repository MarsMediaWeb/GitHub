//Метод Object.keys()

const info = {
    name: "Bakir",
    age: 21,
    city: null,
    prof: "front-end"
}


const infoKeys = Object.keys(info)

const infoValues = Object.values(info)

const infoEntries = Object.entries(info)

const infoExtra = {
    surname: "Kozhegulov",
    color: "red",
    growth: 185
}

const obj2 = Object.assign(info, infoExtra)

const user = {
    name: "6akus",
    password: "12345678"
}

// const protectUser = Object.freeze(user)

// const protectUser = Object.seal(user) 

// protectUser.password = "abcd"

// protectUser.lol = "lol"

// console.log(protectUser)



const arr = [
    {name: "Dima", age: 34, city: "London", id: 78},
    {name: "John", age: 19, city: "New York", id: 23},
    {name: "Bakir", age: 10, city: "Bishkek", id: 54},
    {name: "Peter", age: 45, city: "New York", id: 37}
]


const forEach = arr.forEach((item, index, array) => {
    return item
})

const map = arr.map((item) => {
    return item
})

const filter = arr.filter(item => item.age > 18)

const arrNumbers = [100, 50, 50, 40, 60]

// const sort = arrNumbers.sort((a, b) => b - a)

// const sort = arrNumbers.sort((a, b) => {
//     if(a > b){
//         return -1
//     }if(a < b){
//         return 1
//     }
//     return 0
// })

const reduce = arrNumbers.reduce((state, item) => {
    return state + item 
}, 0)



//деструктуризация

const arrNames = ["Bakir", "Sanjar", "Oleg", "Akniet"]

const [name1, name2,,name4] = arrNames

// console.log(name1)

// console.log(name2)

// console.log(name4)


const car = {
    mark: "Honda",
    color: "white",
    year: 2022,
    country: "Japan"
}

const { year ,mark, lol } = car

// console.log(year)

// console.log(mark)

// console.log(lol)

let arr1 = ['a', 'b', 'c']

let arr2 = [1, 2, 3, 4, 5]

console.log(arr1.concat(arr2))


arr1.push(1, 2, 3)

console.log(arr1)

console.log(arr2.slice(0, 3))

console.log(arr2.slice(3))

