// Создайте функцию с двумя аргументами, которая будет возвращать
// массив первых n кратных x.

// Предположим, что и заданное число, и количество раз для подсчета
// будут положительными числами больше, чем 0.

// Возвращайте результаты в виде массива или списка (в зависимости от языка).

// Примеры
// countBy(1,10) === [1,2,3,4,5,6,7,8,9,10]
// countBy(2,5) === [2,4,6,8,10]

const countBy = (n1, n2) => {
  let arrAnswer = [];

  let increase = 0;

  for (let i = 0; i < n2; i++) {
    increase += n1;

    arrAnswer[i] = increase;
  }

  return arrAnswer;
};

// console.log(countBy(1,10))

// Суммирование
// Напишите программу, которая находит сумму всех чисел от 1 до num.
// Число всегда будет положительным целым числом больше 0.

// Например:

// summation(2) -> 3
// 1 + 2

// summation(8) -> 36
// 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8

// const summation = (num) =>{
//     let sum = 0
//     for(let i = 1; i <= num; i++){
//         sum += i
//     }

//     return sum
// }

// console.log(summation(8))

//Методы строки

let str = "Hi, Bakir";

// console.log(str[2])

// str[2] = 'h'

// console.log(str)

// console.log(str.length) //Кол симболов в строке

// console.log(str.toLocaleLowerCase())

// console.log(str.toLocaleUpperCase())

// console.log(str.replace("i","B"))

// console.log(str.replaceAll("i","B"))

// let arr = str.split("i")

// let index = str.indexOf("i")

// let hi = str.slice(0, 2)

// console.log(hi)

//Методы массивов

let arr = ["hello", true, 23, "age", 5];

// delete arr[0]

// arr.pop() // delete last element

// arr.push("jst-07") //add element end

// arr.shift() delete first element

// arr.unshift(null) //add element start

// arr.splice(0, 2, "codify", 'white', "lol")

// let arrNew = arr.slice(0, 3)

// let arrStr = arr.join(" ")

let info = [
  {
    name: "Bakir",
    age: 19,
  },
  {
    name: "Timur",
    age: 23,
  },
  {
    name: "Lena",
    age: 7,
  },
];

// let index = info.indexOf(true)

// let index2 = info.findIndex(function(item, index, array){
//     return item.name === "Lena"
// })

// let index2 = info.findIndex((item) =>  item.name === "Lena")

// let element = info.find((item) =>  item.name === "Bakir")

// let answer = arr.includes("age")


info.forEach((item, index, array) => {
    // console.log(item, "item")
    // console.log(index, "index")
    console.log(array, "array")
})
