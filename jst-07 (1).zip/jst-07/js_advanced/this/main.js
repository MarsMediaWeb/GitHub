function sayHello(){
    // console.log(`hello ${this.name}`)

    console.log(this)
}

const info = {
    name: "Bakir",
    surname: "Kozhegulov",
    age: 22,
    city: null,
    // hello: function(){
    //     console.log(this.name)
    //     console.log(`Hello ${info.name}`)
    // }
    hello: sayHello
}

const info2 = {
    name: "Azim",
    age: null,
    hello: sayHello
}

function sum(){
    console.log(this.clothes + this.food + this.payment + this.cinematic)
}


const shop1 = {
    clothes: 35,
    food: 844,
    payment: 76,
    cinematic: 434,
    report: sum
}
const shop2 = {
    clothes: 34,
    food: 290,
    payment: 434,
    cinematic: 34,
    report: sum
}
const shop3 = {
    clothes: 354,
    food: 84443,
    payment: 7434,
    cinematic: 4344,
    report: sum
}

shop1.report()
shop2.report()
shop3.report()



const car = {
    mark: "Honda",
    color: "red",
    year: 2019,
    // infoCar: () => {
    //     console.log(`Car ${this.mark} - ${this.year} ( ${this.color} )`)
    // }

    infoCar: function (){
        return () => {
            console.log(`Car ${this.mark} - ${this.year} ( ${this.color} )`)
        }
    }
}

// car.infoCar()()



//bind, call, apply

const classA = {
    st1: "Maxim",
    st2: "Altai",
    st3: "Sanjar",
    students: function(nameTeacher){
        console.log(nameTeacher + "- teacher", this.st1, this.st2, this.st3)
    }
}

const classB = {
    st1: "Bakir",
    st2: "Salih",
    st3: "Amir"
}


classA.students.bind(classB)("Akniet bind")

classA.students.call(classB, "Akniet call")

classA.students.apply(classB,["Akniet apply"])

