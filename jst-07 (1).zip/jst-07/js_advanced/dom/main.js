// const list = document.querySelector(".list")

// // const listNames = document.querySelector("#listNames")

// // const listTag = document.querySelector("ol")

// const li = document.querySelectorAll(".list>li")

// const listId = document.getElementById("listNames")

// const listClass = document.getElementsByClassName("list")


const nameDima = document.getElementById("dima")

const ol = nameDima.parentNode

// const children = ol.childNodes

// const childrenLi = ol.children

// const firstLi = ol.firstChild

// const nameBakir = nameDima.previousSibling


// document.body.style.backgroundColor = "red"

// ol.style.color = "white"


nameDima.classList.add("list-font")

nameDima.classList.remove("nameDima")





