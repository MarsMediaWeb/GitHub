const box = document.querySelector(".box-text");

const year = 2022 - 15;

box.style.backgroundColor = "red";

box.textContent = "Hello";

box.innerHTML = `<b>
   Возраст - ${year}
</b>`;


const hello = () =>{
    alert("Hello!")
}

const btn = document.querySelector(".btn-hello")

btn.addEventListener('click', () => {
    alert("hello")
    console.log(event)
})


const input = document.querySelector(".input")

input.addEventListener('input', (e) => {
    console.log(e.target.value)
})


const select = document.querySelector(".select")

select.addEventListener('change', (e) => {
    console.log(e.target.value)
})

const circle = document.getElementById("circle")

circle.addEventListener("focus", () => {
    circle.classList.toggle("circle-green")
})

circle.addEventListener("mouseover", () => {
    circle.classList.toggle("circle-green")
    console.log("hover")
})