//Math

let n = 2 ** 3;

// console.log(n)

// console.log(Math.pow(3, 2))

// let sq = Math.sqrt(16)

// console.log(sq)

// console.log(81 ** 0.5)

// console.log(Math.floor(2.753))

// console.log(Math.floor(2.45))

// console.log(Math.floor(6.99))

// console.log(Math.round(10.45))

// console.log(Math.round(4.51))

// console.log(Math.random())

// let randomNumber = Math.floor(Math.random() * 1000)

// console.log(randomNumber)

//Date

let date = new Date();

let year = date.getFullYear();

let day = date.getDate();

let month = date.getMonth() + 1;

console.log(day, month, year);

//??

// let str = "Hello"

// let str

// let str = null

// let str = false

// console.log(str ?? "null or undefined")

// Меньше 100?
// Даны два числа, возврат, trueесли сумма обоих чисел меньше 100.
// В противном случае возврат false.

// Примеры
// lessThan100(22, 15) ➞ true
// // 22 + 15 = 37

// lessThan100(83, 34) ➞ false
// // 83 + 34 = 117

// lessThan100(3, 77) ➞ true

function lessThan100(n1, n2) {
  if (n1 + n2 < 100) {
    return true;
  } else {
    return false;
  }
}

// console.log(lessThan100(56, 20))

// console.log(lessThan100(100, 20))

// Сравните строки по количеству символов
// Создайте функцию, которая принимает две строки в качестве аргументов
// и возвращает значение trueили falseв зависимости от того, равно
// ли общее количество символов в первой строке общему количеству
// символов во второй строке.

// Примеры
// comp("AB", "CD") ➞ true

// comp("ABC", "DE") ➞ false

// comp("hello", "edabit") ➞ false

const comp = (str1, str2) => (str1.length === str2.length ? true : false);

// console.log(comp("hello", "lkfsopfnsoinfs"))

// Преобразование массива в строку
// Создайте функцию, которая принимает массив чисел или
// букв и возвращает строку.

// Примеры
// arrayToString([1, 2, 3, 4, 5, 6]) ➞ "123456"

// arrayToString(["a", "b", "c", "d", "e", "f"]) ➞ "abcdef"

// arrayToString([1, 2, 3, "a", "s", "dAAAA"]) ➞ "123asdAAAA"

const arrayToString = (arr) => {
  let answer = "";
  for (let i = 0; i < arr.length; i++) {
    answer += arr[i];
  }
  return answer;
};

// console.log(arrayToString([1, 2, 3, "a", "s", "dAAAA"]))

// Много операторов!
// Некоторые основные арифметические операторы
// +, -, *, /и %. В этом задании вам будут даны три
// параметра: num1, num2, и operator. Используйте оператора на номер 1 и 2.

// Примеры
// operate(1, 2, "+") ➞ 3
// // 1 + 2 = 3

// operate(7, 10, "-") ➞ -3
// // 7 - 10 = -3

// operate(20, 10, "%") ➞ 0
// 20 % 10 = 0

function operate(n1, n2, sym) {
  switch (sym) {
    case "+":
      return n1 + n2;
    case "-":
      return n1 + n2;
    case "%":
        return n1 % n2
    case "/":
        return n1 / n2
  }
}

console.log(operate(20,30, "+"))