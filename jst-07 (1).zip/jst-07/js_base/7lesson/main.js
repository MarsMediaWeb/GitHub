//Типы данных
//Boolean( true, false ), undefined, number, string, object, null, bigInt, symbol

// undefined

// let name

// console.log(name)


//number

let n = 20 / 5

// console.log(n)


//String

let text = "lorem"

// console.log(typeof text)

//null

// console.log(typeof null)


//var, let, const

// console.log(name) error

let name = "codify"

name = "Bakir"

// console.log(name)

const pi = 3.14

// pi = 100 error

// console.log(pi)



//Матем. вычисления 

// ( / ) - деление

// ( * ) - умножение

// ( - ) - минус

// ( + ) - плюс

// ( ** ) степень



//Преобразование типов

//Number

let x1 = 2 * "2"

let x2 = "2" / "2"

let sum = "year-" + 2

// console.log("year" * 2) NaN

// console.log(typeof -"2") number

let num = "2000"

// console.log(num)

// console.log(Number(num))

// console.log(Number("Hello"))

// console.log(Number(undefined))

// console.log(Number(null))

// console.log(Number(true))

// console.log(Number(false))


//String

// console.log(true + "", true)

// console.log(String(200))

// console.log(String(false), false)

//Boolean

// console.log(Boolean(null), "null")

// console.log(Boolean(""), "empty")

// console.log(Boolean(" "), "full")

// console.log(Boolean(200), "200")

// console.log(Boolean(-200), "-200")

// console.log(Boolean(1), "1")

// console.log(Boolean(0), "0")

// console.log(Boolean(undefined), "undefined")


//alert, promt, confirm

// alert("Hello world")

// let value = prompt("Сколько тебе лет?", 6)

// console.log(value)

let answer = confirm("Ты старше 12 лет?")

// console.log(answer)