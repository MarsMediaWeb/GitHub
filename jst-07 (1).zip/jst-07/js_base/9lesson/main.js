//for, while
// let i = 5

// while(i < 5){
//     console.log(i, "- while")
//     i++
// }

// let j = 5

// do {
//   console.log(j, "- do")
//   j++;
// } while (j < 5);

// let arr = ["hello", 1, 20, true]

// for(let i = 0; i < arr.length; i++){
//     console.log(arr[i])
// }


let arrNum = [9, 2, 3, 4, 12, 11]

// for(let i = 0; i < arrNum.length; i++){ //четные
//     if(arrNum[i] % 2 == 0){ 
//         console.log(arrNum[i])
//     }
// }
// for(let i = 0; i < arrNum.length; i++){ // нечетные
//     if(arrNum[i] % 2 !== 0){
//         console.log(arrNum[i])
//     }
// }
let sum = 0

// for(let i = 0; i < arrNum.length; i++){ // общая сумма массива
//     sum = sum + arrNum[i]
// }


let f = 10

let answer = 1

for(let i = 1; i <= 10; i++){
    answer *= i
}

// console.log(answer)

//!10 = 1 * 2 * 3 * 4 * 5 * 6 * 7 * 9 * 10

//!4 = 1 * 2 * 3 * 4 ( 24 )
//!3 = 1 * 2 * 3 ( 6 )



//function

// sumFun(1000, 1000) // no error

function sumFun(num1, num2){
    let sum = num1 + num2
    console.log(sum)
}

// sumFun(10, 3)

// sumFun(17, 3)

// sumFun(297, 98)


function n(num1){
    if(num1 % 2 === 0){
        console.log(true)
    }else{
        console.log(false)
    }
}

function num(num1){
    return num1 ** 2
}

// console.log(num(4))

// let sum10 = num(2) + 10

// console.log(sum10)


// hello("Bakir") //error

let hello = function(name){
    console.log("hello " + name)
}

// hello("Bakir")


// let age = (n) => {
//     return n > 18 ? "Взрослый" : "Ребенок"
// }
// let age = n => {
//     return n > 18 ? "Взрослый" : "Ребенок"
// }
let age = n => n > 18 ? "Взрослый" : "Ребенок"

// console.log(age(10))



// Преобразование минут в секунды
// Напишите функцию, которая принимает целое число 
// minutesи преобразует его в секунды.

// Примеры
// convert(5) ➞ 300

// convert(3) ➞ 180

// convert(2) ➞ 120
// Заметки
// Не забывайте returnо результате.
// Если вы застряли на задании, найдите помощь на вкладке « Ресурсы ».
// Если вы действительно застряли, разблокируйте решения на вкладке « Решения ».

