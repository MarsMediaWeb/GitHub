// >, <, ==, ===

// console.log(5 > 3)

// console.log(-5 > 3)

// console.log("a" == "A")

// console.log("a" == "a")

// console.log(true == false)

// console.log(false == 0)

// console.log(false === 0)

//Логические операторы ( &&, ||, ! )

//&& - И

// || - ИЛИ

// ! - НЕ

// console.log(true && true)
// console.log(false && false)
// console.log(true && false)
// console.log("--------------")
// console.log(true || true)
// console.log(false || false)
// console.log(true || false)

// console.log(!true)

// console.log(!false)

// console.log(20 != 40)

// console.log(20 != 20)

// console.log("" && 20)

// console.log(20 && "")

// console.log(20 && "text")

// console.log("text" && 20)

// console.log( true || false || false || true || false ) //==> true
// console.log( true && false && true && true && false  ) //==> false

//if, else if, else

// let age = prompt("Сколько тебе лет?")

// if(age <= 17){
//     alert("Ты школьник :)")
// }else if(age > 17){
//     alert("Ты уже взрослый :(")
// }else{
//     alert("Error!!!")
// }

//Switch case

let text = "салам";

// switch (text) {
//   case "привет":
//     console.log("русс. яз.");
//     break;
//   case "салам":
//     console.log("кыр. яз");
//     break;
//   case "hello":
//     console.log("анг. яз.");
//     break;
//   default:
//     console.log("Нету данного слова")
// }

// if(text === "привет"){
//     console.log("русс. яз.");
// }else if(text === "салам"){
//     console.log("кыр. яз");
// }else if(text === "hello"){
//     console.log("анг. яз.");
// }else{
//     console.log("Нету данного слова")
// }


let n = 10


// if(n >= 6 && n <= 17 && n !== 10){
//     console.log(true)
// }
// if(n >= 6 || n <= 17 || n !== 10){
//     console.log(false)
// }


//Array, Object

let info = {
    name: "Bakir",
    // surname: "Kozhegulov",
    age: 21,
    city: null
}

// console.log(info)

// console.log(info.name)

// console.log(info.age)

// console.log(info.city)

// console.log(info.surname)

// info.city = "Bishkek"

// console.log(info)


// let country = "Kyrgystan"

// let c = country

// c = "New York"

let country = {
    name: "Kyrgystan"
}

let c = country

c.name = "New York"

// console.log(c)

// console.log(country)


const q = {
    letter: "q"
}

q.letter = "a"

console.log(q)