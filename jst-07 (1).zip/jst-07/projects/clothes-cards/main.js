fetch("https://6108e442d71b67001763960c.mockapi.io/clothes")
  .then((res) => res.json())
  .then((data) => {
    const box = document.querySelector(".container");

    console.log(data)

    data.map((item) => {
      box.innerHTML += ` <div class="card">
            <div class="box-img">
                <img src="${item.img}" alt="">
            </div>
            <p>${item.name}</p>
            <p>Цена: ${item.price} сом</p>
            <button>КУПИТЬ</button>
        </div>`;
    });
  });
